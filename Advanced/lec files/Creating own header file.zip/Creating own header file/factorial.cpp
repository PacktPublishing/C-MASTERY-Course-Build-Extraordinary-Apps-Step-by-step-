#include <factorial.h>
#include <iostream>
using namespace std;

int main()
{
    cout<<"Welcome to my udemy course"<<endl;
    int positive_integer;
    cout<<"Enter a positive integer: "<<endl;
    cin>>positive_integer;
    cout<<"Factorial of "<<positive_integer<<"is :"<<factorial(positive_integer)<<endl;
    return 0;
}
